@extends('layouts.app')

@section('content')

<asignaciones-vue> </asignaciones-vue>
@endsection
