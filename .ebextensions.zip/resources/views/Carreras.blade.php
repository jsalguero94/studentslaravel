@extends('layouts.app')

@section('content')

<carreras-vue> </carreras-vue>
@endsection
