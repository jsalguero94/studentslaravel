@extends('layouts.app')

@section('content')

<cursos-vue> </cursos-vue>
@endsection
