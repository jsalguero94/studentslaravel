@extends('layouts.app')

@section('content')

<estudiantes-vue> </estudiantes-vue>
@endsection
