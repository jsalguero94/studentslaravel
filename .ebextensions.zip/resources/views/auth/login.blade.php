@extends('layouts.app')

@section('content')
@include('auth.onlylogin')
@endsection
